export const FONTS = {
  REGULAR: 'Roboto_400Regular',
  BOLD: 'Roboto_700Bold',
} 