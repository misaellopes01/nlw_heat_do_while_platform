export const MESSAGES_EXAMPLE = [
  {
    id: '1',
    text: 'Não vejo a hora de começar esse evento, com certeza vai ser o melhor de todos os tempos, vamooo pra cima! 🔥🔥',
    user: {
      name: 'Dianne Russell',
      avatar_url: 'https://randomuser.me/api/portraits/men/32.jpg'
    }
  },
  {
    id: '2',
    text: 'Esse vai ser simplesmente fantástico! Bora aprender tudo em relação a montagem de APIs GraphQL. Sem contar com as palestras e painéis.',
    user: {
      name: 'Guy Hawkins',
      avatar_url: 'https://randomuser.me/api/portraits/men/43.jpg'
    }
  },
  {
    id: '3',
    text: 'Sem dúvida as palestras vão ser úteis para a minha carreira e para a de muitos 😍 #gorocket',
    user: {
      name: 'Eleanor Pena',
      avatar_url: 'https://uifaces.co/our-content/donated/6f6p85he.jpg'
    }
  }
];